
import glob
import pandas as pd

def shuffle(path):
    pass


if __name__=="__main__":
    pass